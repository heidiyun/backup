import processing.core.PApplet;

public class Block implements Constants {
    private Vector2 vector;
    private int item;
    private int color;
    private int life;

    public Block(int x, int y, int color, int item, int life) {
//        this.vector = new Vector2(x, y);
        this.vector = Util.indexToCoord(x, y);
        this.color = color;
        this.item = item;
        this.life = life;
    }

    public void render(PApplet pApplet) {
        setBlockColor(pApplet);
        pApplet.rect(vector.getX() - BLOCK_WIDTH / 2 , vector.getY() - BLOCK_HEIGHT / 2, BLOCK_WIDTH, BLOCK_HEIGHT);
        pApplet.fill(0);
        pApplet.text(item + "," + life,  vector.getX() + BLOCK_WIDTH / 4, vector.getY() + BLOCK_HEIGHT / 2);
    }

    public boolean isCollision(float ballX, float ballY) {
//        System.out.println("block: " + vector.getX() + ", " + vector.getY());
        return (ballX > (vector.getX() - (BLOCK_WIDTH / 2) - BALL_RADIUS)
                && ballX < (vector.getX() + (BLOCK_WIDTH / 2) + BALL_RADIUS)
                && ballY > (vector.getY() - (BLOCK_HEIGHT / 2) - BALL_RADIUS)
                && ballY < (vector.getY() + (BLOCK_HEIGHT / 2) + BALL_RADIUS));
    }

    private void setBlockColor(PApplet pApplet) {
        if (color == 5) {
            pApplet.fill(255);
        } else if (color == 6) {
            pApplet.fill(255, 102, 0);
        } else if (color == 7) {
            pApplet.fill(0, 255, 255);
        } else if (color == 8) {
            pApplet.fill(0, 255, 0);
        } else if (color == 9) {
            pApplet.fill(255, 0, 0);
        } else if (color == 10) {
            pApplet.fill(0, 0, 255);
        } else if (color == 11) {
            pApplet.fill(255, 0, 255);
        } else if (color == 12) {
            pApplet.fill(255, 255, 0);
        } else if (color == 20) {
            pApplet.fill(204, 204, 204);
        } else if (color == 30) {
            pApplet.fill(204, 204, 0);
        } else if (color == 13) {
            pApplet.fill(0);
        }
    }

    public void setColor(int color) {
        this.color = color;
    }
}
