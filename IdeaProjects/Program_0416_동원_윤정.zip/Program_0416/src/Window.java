import processing.core.PApplet;


public class Window extends PApplet implements Constants {
    Block[][] blocks = new Block[100][13];
    private Ball ball;
    private boolean ballPressed = false;

    public void settings() {
        size(800, 900);
    }

    public void setup() {
        String[][] s = CsvFileManager.getCsvArray("./data/map.dat");

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 13; j++) {
                blocks[i][j] = new Block(j, i, Integer.parseInt(s[i][j].split("-")[0]) / 10,
                        Integer.parseInt(s[i][j].split("-")[0]) % 10,
                        Integer.parseInt(s[i][j].split("-")[1]));
            }
        }

        ball = new Ball(400, 400);
    }

    public void draw() {
        background(0);


        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 13; j++) {
                    blocks[i][j].render(this);
            }
        }

        if (mousePressed) {
            System.out.println(mouseX + "," + mouseY);
            for (int i = 0; i < 6; i++) {
                for (int j = 0; j < 13; j++) {
                    if (blocks[i][j].isCollision(ball.getVector2().getX(), ball.getVector2().getY())) {
                        blocks[i][j].setColor(BLOCK_BLACK);
                    }
                }
            }

            if (ball.isCollision(mouseX, mouseY)) {
                ballPressed = true;
            }
        } else {
            ballPressed = false;
        }

        if (ballPressed) {
            ball.getVector2().setXY(mouseX, mouseY);
        }

        ball.render(this);

    }


}
