import processing.core.PApplet;

public class Ball implements Constants {
    private Vector2 vector2;

    public Ball(int x, int y) {
        vector2 = new Vector2(x,y);
    }

    public void render(PApplet pApplet) {
        pApplet.fill(255);
        pApplet.ellipse(vector2.getX(), vector2.getY(), BALL_RADIUS * 2,BALL_RADIUS * 2);
    }

    public boolean isCollision(int mouseX, int mouseY) {
        return vector2.distance(mouseX, mouseY) < BALL_RADIUS;
    }

    public Vector2 getVector2() {
        return vector2;
    }
}
