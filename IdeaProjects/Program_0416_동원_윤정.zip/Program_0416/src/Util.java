public class Util implements Constants {
    public static Vector2 indexToCoord(int x, int y) {
        Vector2 vector2 = new Vector2(x * BLOCK_WIDTH + MARGIN, y * BLOCK_HEIGHT + MARGIN);
        return vector2;
    }
}
