package Models;

import Utils.Constants;
import Utils.Vector2;
import processing.core.PApplet;

public class Ball implements Constants {
    private Vector2 pos;
    private Vector2 velocity;

    public Ball(float x, float y) {
        pos = new Vector2(x, y);
        velocity = new Vector2(0, 0);
    }

    public void update() {
        checkWall();
        pos.add(velocity);
    }

    public void render(PApplet pApplet) {
        pApplet.fill(255);
        pApplet.ellipse(pos.getX(), pos.getY(), Constants.BALL_RADIUS * 2, Constants.BALL_RADIUS * 2);
    }

    public void checkWall() {
        if (pos.getX() <= MARGIN_HORIZONTAL || pos.getX() >= WINDOW_WIDTH - MARGIN_HORIZONTAL) {
            velocity.setX(velocity.getX() * -1);
        }
        if (pos.getY() <= MARGIN_VERTICAL) {
            velocity.setY(velocity.getY() * -1);
        }

    }

    public Vector2 getPos() {
        return pos;
    }

    public Vector2 getVelocity() {
        return velocity;
    }
}
