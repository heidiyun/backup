import Models.Ball;
import Models.Bauss;
import Models.Block;
import Models.Item;
import Utils.Constants;
import Utils.CsvFileManager;
import Utils.Util;
import Utils.Vector2;
import dwon.SpriteManager.SpriteManager;
import processing.core.PApplet;

import java.util.ArrayList;
import java.util.List;

public class Window extends PApplet implements Constants {
    Block[][] blocks = new Block[100][13];
    private Ball ball;
    private boolean ballPressed = false;
    private List<Item> items = new ArrayList<>();
    private Bauss bauss;
    private boolean isPressedRight;
    private boolean isPressedLeft;
    private List<LaserBall> laserBalls = new ArrayList<>();
    private boolean start = false;

    public void settings() {
        size(WINDOW_WIDTH, WINDOW_HEIGHT);
    }

    public void setup() {
        setupMap();
        bauss = new Bauss();
        ball = new Ball(bauss.getPos().getX() + 5, bauss.getPos().getY() - Constants.BAUSS_HEIGHT / 2 - BALL_RADIUS);
        loadImage();
    }

    public void setupMap() {
        String[][] s = CsvFileManager.getCsvArray("./data/map.dat");

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 13; j++) {
                blocks[i][j] = new Block(j, i, (Integer.parseInt(s[i][j]) / 100) * 10,
                        Integer.parseInt(s[i][j]) % 100 / 10,
                        Integer.parseInt(s[i][j]) % 10);
            }

        }
    }


    public void draw() {
        background(0);

        drawBlocks();
        drawItems();
        drawBall();
        drawLaserBalls();
        drawBauss();

        if (CollisionChecker.rectCircleCollision(bauss.getPos(), ball.getPos(), BAUSS_WIDTH, BAUSS_HEIGHT, BALL_RADIUS) && start) {
            float diff = Util.difference(ball.getPos().getX(), bauss.getPos().getX());
            System.out.println(diff);
            if (diff > 0) {
                if (ball.getVelocity().getX() < 0) {
                    ball.getVelocity().setX(ball.getVelocity().getX() * -1);
                }
                ball.getVelocity().setX(ball.getVelocity().getX() * (diff / 10));
                ball.getVelocity().setY(ball.getVelocity().getY() * -1);
            } else {
                ball.getVelocity().setX(ball.getVelocity().getX() * (diff / 10));
                ball.getVelocity().setY(ball.getVelocity().getY() * -1);
            }
        }
    }

    public void drawBlocks() {
        renderBlocks();
        destroyBlock();
    }

    public void drawLaserBalls() {
        for (LaserBall laserBall : laserBalls) {
            laserBall.render(this);
            laserBall.update();
        }
    }

    public void drawItems() {
        for (Item item : items) {
            if (CollisionChecker.rectCollision(bauss.getPos(), item.getPos(), BAUSS_WIDTH, BAUSS_HEIGHT, ITEM_WIDTH, ITEM_HEIGHT)) {
                item.setCollision();
                bauss.setItemState(item.getState());
            }
            item.update();
            item.render(this);
        }
    }

    public void drawBauss() {
        moveBauss();
        bauss.update();
        bauss.render(this);
    }

    public void drawBall() {
        initBall();
        ball.update();
        ball.render(this);
    }

    public void addItem(Block block) {
        if (block.getItem() != 0)
            items.add(new Item(block.getPos(), block.getItem()));
    }

    public void destroyBlock() {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 13; j++) {
                if (CollisionChecker.rectCircleCollision(blocks[i][j].getPos(), ball.getPos(), BLOCK_WIDTH, BLOCK_HEIGHT, BALL_RADIUS)
                        && !blocks[i][j].isDestroyed()) {
                    blocks[i][j].destroy();
                    addItem(blocks[i][j]);
                }
            }
        }
    }

    public void initBall() {
        if (!start && millis() > 2000) {
            ball.getVelocity().setY(-BALL_SPEED);
            ball.getVelocity().setX(BALL_SPEED / 2);
            start = true;
        }
    }

    public void moveBauss() {
        if (isPressedRight) bauss.moveRight();
        if (isPressedLeft) bauss.moveLeft();
    }

    public void renderBlocks() {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 13; j++) {
                blocks[i][j].render(this);
            }
        }
    }

    public void loadImage() {

        SpriteManager.loadSprites(this, ITEM_PLAYER, "./images/item_player.png", 0, 0, 80, 44, 8);
        SpriteManager.loadSprites(this, ITEM_LASER, "./images/item_laser.png", 0, 0, 80, 44, 8);
        SpriteManager.loadSprites(this, ITEM_EXTEND, "./images/item_extend.png", 0, 0, 80, 44, 8);
        SpriteManager.loadSprites(this, ITEM_CLASP, "./images/item_clasp.png", 0, 0, 80, 44, 8);
        SpriteManager.loadSprites(this, ITEM_SLOW, "./images/item_slow.png", 0, 0, 80, 44, 8);
        SpriteManager.loadSprites(this, ITEM_BONUS, "./images/item_bonus.png", 0, 0, 80, 44, 8);
        SpriteManager.loadSprites(this, ITEM_DOOM, "./images/item_doom.png", 0, 0, 80, 44, 8);
        SpriteManager.loadSprites(this, BAUSS_NORMAL, "./images/bauss.png", 0, 0, 152, 56, 6);
        SpriteManager.loadSprites(this, BAUSS_LASER, "./images/bauss_laser.png", 0, 0, 152, 56, 6);
        SpriteManager.loadSprites(this, BAUSS_EXTEND, "./images/bauss_extended.png", 0, 0, 228, 56, 6);

        SpriteManager.loadImage(this, BLOCK_BLUE, "./images/block_blue.png");
        SpriteManager.loadImage(this, BLOCK_WHITE, "./images/block_white.png");
        SpriteManager.loadImage(this, BLOCK_ORANGE, "./images/block_orange.png");
        SpriteManager.loadImage(this, BLOCK_SKYBLUE, "./images/block_skyblue.png");
        SpriteManager.loadImage(this, BLOCK_GREEN, "./images/block_green.png");
        SpriteManager.loadImage(this, BLOCK_RED, "./images/block_red.png");
        SpriteManager.loadImage(this, BLOCK_PINK, "./images/block_pink.png");
        SpriteManager.loadImage(this, BLOCK_YELLOW, "./images/block_yellow.png");
        SpriteManager.loadImage(this, BLOCK_HARD, "./images/block_hard.png");
        SpriteManager.loadImage(this, BLOCK_IMMORTAL, "./images/block_immortal.png");
    }

    public void keyPressed() {
        switch (keyCode) {
            case LEFT:
                isPressedLeft = true;
                break;
            case RIGHT:
                isPressedRight = true;
                break;
            case 32:
                laserBalls.add(new LaserBall(bauss.getPos().getX() - BAUSS_WIDTH / 2, bauss.getPos().getY()));
                laserBalls.add(new LaserBall(bauss.getPos().getX() + BAUSS_WIDTH / 2, bauss.getPos().getY()));
                break;

        }
    }

    public void keyReleased() {
        switch (keyCode) {
            case LEFT:
                isPressedLeft = false;
                break;
            case RIGHT:
                isPressedRight = false;
                break;
        }

    }
}
