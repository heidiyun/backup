import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class SendingThread implements Runnable {
    private SendingConsumer sendingConsumer = new SendingConsumer();

    private Client client;

    {
        try {
            client = new Client();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            OutputStream os = client.getOutputStream();

            for (int i = 0; i < sendingConsumer.getSendingWords().size(); i++) {
                os.write(sendingConsumer.getSendingWords().get(i).getBytes());
                sendingConsumer.getSendingWords().remove(sendingConsumer.getSendingWords().get(i));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class SendingConsumer {
    private static List<String> sendingWords = new ArrayList<>();

    public List<String> getSendingWords() {
        return sendingWords;
    }
}
