import dwon.SpriteManager.SpriteManager;
import processing.core.PApplet;

import java.util.ArrayList;
import java.util.List;

public class Window extends PApplet {
    private Thread readingThread;
    private Thread sendingThread;
    private SendingConsumer sendingConsumer;
    private Consumer consumer;
    private List<Word> words;
    private List<Word> removeWords;
    private List<Character> characters;
    private StringBuilder inputWord;
    private int score;
    private int hundredSeat;
    private int tenSeat;
    private int oneSeat;

    public Window() {
    }

    public void settings() {
        size(960, 640);
    }

    public void setup() {
        loadImage();
        consumer = new Consumer();
        sendingConsumer = new SendingConsumer();
        inputWord = new StringBuilder();
        words = new ArrayList<>();
        removeWords = new ArrayList<>();
        characters = new ArrayList<>();


        readingThread = new Thread(new ReadingThread());
        readingThread.start();
        sendingThread = new Thread(new SendingThread());
        sendingThread.start();
    }

    public void draw() {
        background(255);

        if (consumer.getWords().size() > 0) {
            words.add(new Word(this, consumer.getWords().remove(0)));
            // consumer.getWords().remove(0);
        }

        for (Word word : words) {
            word.update();
            word.render();
            if (!word.getIsAppear())
                removeWords.add(word);
        }

        for (Word word : removeWords) {
            words.remove(word);
        }

        removeWords.clear();

        fill(255);
        stroke(70, 0, 80);
        rect(350, 570, 200, 50);
        fill(0, 70, 80);


        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < characters.size(); i++) {
            builder.append(characters.get(i));
        }
        text(builder.toString(), 375, 600);

        for (Word word : words) {
            if (word.getWord().equals(inputWord.toString())) {
                sendingConsumer.getSendingWords().add(word.toString());
//                score += word.getScore();
//                removeWords.add(word);
            }
        }

        showScore(score);

    }

    public void showScore(int score) {
        if (score < 10) {
            hundredSeat = 0;
            tenSeat = 0;
            oneSeat = 0;
        } else if (score < 100) {
            hundredSeat = 0;
            tenSeat = score / 10;
            oneSeat = score % 10;
        } else  {
            hundredSeat = score / 100;
            tenSeat = score % 100 / 10;
            oneSeat = score % 10;
        }

        image(SpriteManager.getImage(hundredSeat, 0), 800, 100, 50, 50);
        image(SpriteManager.getImage(tenSeat, 0), 850, 100, 50, 50);
        image(SpriteManager.getImage(oneSeat, 0), 900, 100, 50, 50);

    }

    public void keyPressed() {
        if (keyCode == ENTER) {
            inputWord.setLength(0);
            for (Character word : characters) {
                inputWord.append(word);
            }
            characters.clear();
        } else if (keyCode == BACKSPACE) {
            if (characters.size() > 0)
                characters.remove(characters.size() - 1);
        } else {
            characters.add(key);
        }
    }

    public void loadImage() {
        SpriteManager.loadImage(this, 0, "./data/0.png");
        SpriteManager.loadImage(this, 1, "./data/1.png");
        SpriteManager.loadImage(this, 2, "./data/2.png");
        SpriteManager.loadImage(this, 3, "./data/3.png");
        SpriteManager.loadImage(this, 4, "./data/4.png");
        SpriteManager.loadImage(this, 5, "./data/5.png");
        SpriteManager.loadImage(this, 6, "./data/6.png");
        SpriteManager.loadImage(this, 7, "./data/7.png");
        SpriteManager.loadImage(this, 8, "./data/8.png");
        SpriteManager.loadImage(this, 9, "./data/9.png");
    }
}
