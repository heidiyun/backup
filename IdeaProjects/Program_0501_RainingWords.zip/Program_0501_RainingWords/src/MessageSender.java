public class MessageSender {


    public MessageSender(){

    }

    public void start(){

    }

    public void send(String s){

    }
}
