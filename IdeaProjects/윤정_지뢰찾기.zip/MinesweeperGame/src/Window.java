import processing.core.PApplet;

public class Window extends PApplet {

    private Map map = new Map(this, 10, 10);

    public void settings() {
        size(960, 640);
        map.setMineInMap();
    }

    public void mouseClicked() {

    }
    public void setup() {
        background(0);
    }

    public void draw() {
        background(0);
        map.render();
    }
}

