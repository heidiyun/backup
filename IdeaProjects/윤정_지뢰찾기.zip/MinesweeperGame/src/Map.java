import processing.core.PApplet;

public class Map {
    private int width;
    private int height;
    private int[][] map;
    private PApplet pApplet;
    private float x;
    private float y;

    public Map(PApplet pApplet, int width, int height) {
        this.width = width;
        this.height = height;
        this.pApplet = pApplet;
        map = new int[width][height];
        x = 960 / width;
        y = 640 / height;
    }

    private int[] shuffle() { // 그냥 랜덤값만 쓸때는, 계속해서 같은 랜덤 값이 중복될 수 있으니까.
        int[] arr = new int[width * height];
        for (int i = 0; i < arr.length; i++) arr[i] = i;

        for (int i = 0; i < arr.length * 3; i++) {
            int a = (int) (Math.random() * arr.length);
            int b = (int) (Math.random() * arr.length);

            int temp = arr[a];
            arr[a] = arr[b];
            arr[b] = temp;
        }
        return arr;
    }

    public void setMineInMap() {

        int[] arr = shuffle();

        for (int i = 0; i < width * height /2 ; i++) {
            map[arr[i] / width][arr[i] % width] = -1;
        }

        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                if (map[i][j] == -1) {
                    if (i - 1 > -1 && j - 1 > -1)
                        ++map[i - 1][j - 1];
                    if (i - 1 > -1 )
                        ++map[i - 1][j];
                    if (i - 1 > -1 && j + 1 < width)
                        ++map[i - 1][j + 1];
                    if (j + 1 < width)
                        ++map[i][j + 1];

                    if (j - 1 > -1 )

                        ++map[i][j - 1];
                    if (i + 1 < height && j - 1 > -1)
                        ++map[i + 1][j - 1];
                    if (i + 1 < height)
                        ++map[i + 1][j];
                    if (i + 1 < height && j + 1 < width)
                        ++map[i + 1][j + 1];

                }
            }
        }
    }


    public void render() {
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                pApplet.fill(240, 240, 240);
                pApplet.rect(i * x, j * y, x, y);
                pApplet.fill(0);
                pApplet.text(map[i][j], i * x + (x / 2), j * y + (y / 2));
            }
        }
    }
}



