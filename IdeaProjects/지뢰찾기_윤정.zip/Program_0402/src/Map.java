
import processing.core.PApplet;
import processing.core.PImage;

import java.util.ArrayList;

public class Map {

    private ArrayList<Block> blocks = new ArrayList<>();
    private PApplet pApplet;
    private boolean clickMineState = false;
    private PImage mineImg;
    private PImage mineFlagImg;
    private int mineCount = Constants.MINE_COUNT;

    public Map(PApplet pApplet) {
        this.pApplet = pApplet;
        for (int i = 0; i < Constants.BLOCK_COUNT_X * Constants.BLOCK_COUNT_Y; i++) {
            blocks.add(new Block(pApplet, i));
        }

        initMine();

        for (Block block : blocks)
            block.makeConnection(blocks);

    }


    public void mineDraw() {
        for (Block block : blocks) {
            if (block.getCheckMine() && block.getVisibleState() == Constants.BLOCK_INVISIBLE) {
                pApplet.image(mineImg, block.getX(), block.getY(), block.BLOCK_SIZE_X, block.BLOCK_SIZE_Y);
            }
            if (block.getBlockState() == Constants.BLOCK_STATE_MINE && block.getVisibleState() == Constants.BLOCK_VISIBLE) {
                pApplet.image(mineFlagImg, block.getX(), block.getY(), block.BLOCK_SIZE_X, block.BLOCK_SIZE_Y);
            }
        }
    }

    public int getMineCount() {
        return mineCount;
    }

    private void initMine() {

        int[] mines = new int[blocks.size()];
        for (int i = 0; i < blocks.size(); i++) {
            mines[i] = i;
        }


        int shuffle = blocks.size() * 3;
        for (int i = 0; i < shuffle; i++) {
            int src = (int) (Math.random() * blocks.size());
            int dst = (int) (Math.random() * blocks.size());

            int temp = mines[src];
            mines[src] = mines[dst];
            mines[dst] = temp;
        }

        for (int i = 0; i < Constants.MINE_COUNT; i++) {
            blocks.get(mines[i])
                    .setBlockState(Constants.BLOCK_STATE_MINE);
        }
    }

    public void render(PImage mineImg, PImage mineFlagImg) {
        this.mineImg = mineImg;
        this.mineFlagImg = mineFlagImg;
        for (Block box : blocks) {
            box.render();
        }

    }

    public void click(char keycode) {
        int index = Util.getIndexByPos(this.pApplet.mouseX,
                this.pApplet.mouseY);

        if (keycode == 'a') {
            if (!blocks.get(index).getCheckMine()) {

                if (blocks.get(index).getBlockState() != Constants.BLOCK_STATE_MINE)
                    blocks.get(index).click(true);
                else {
                    clickMine();
                }
            }
        }

        if (mineCount > 0) {
            if (keycode == 's') {
                if (blocks.get(index).getCheckMine()) {
                    blocks.get(index).setCheckMine(false);
                    mineCount++;
                } else if (blocks.get(index).getVisibleState() != Constants.BLOCK_VISIBLE) {
                    blocks.get(index).setCheckMine(true);
                    mineCount--;
                }
            }
        }

        if (keycode == 'd') {
            if (blocks.get(index).checkConnectionsHasMine())
                clickMine();
        }
    }

    private void clickMine() {
        for (Block block : blocks) {
            if (block.getBlockState() == Constants.BLOCK_STATE_MINE) {
                block.mineClick();
            }
        }

        clickMineState = true;
    }

    public boolean VisibleBlock() {
        int count = 0;
        for (Block block : blocks) {
            if (block.getVisibleState() == Constants.BLOCK_VISIBLE) {
                count++;
            }
        }

        return (count == (Constants.BLOCK_COUNT_X * Constants.BLOCK_COUNT_Y - Constants.MINE_COUNT));

    }

    public boolean getClickMineState() {
        return clickMineState;
    }

    public boolean checkMineEqualsRealMine() {
        int count = 0;
        for (Block block : blocks) {
            if (block.getBlockState() == Constants.BLOCK_STATE_MINE
                    && block.getCheckMine())
                count++;
        }

        return (count == Constants.MINE_COUNT);
    }

}
