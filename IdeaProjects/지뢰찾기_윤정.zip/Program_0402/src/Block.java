import processing.core.PApplet;

import java.util.ArrayList;

public class Block implements Constants {


    private int visibleState;
    private int blockState;
    private int x, y;
    private PApplet pApplet;
    private int index;
    private int neighborMineCount;
    private boolean checkMine;
    private int[] num = new int[MINE_COUNT];
    public static final int BLOCK_SIZE_X = (900 / BLOCK_COUNT_X);
    public static final int BLOCK_SIZE_Y = (700 / BLOCK_COUNT_Y);

    private ArrayList<Block> connections = new ArrayList<>();

    public Block(PApplet pApplet, int index) {
        this.pApplet = pApplet;
        this.blockState = 1;
        setIndex(index);
        this.visibleState = this.BLOCK_INVISIBLE;

    }


    public int getBlockState() {
        return blockState;
    }

    public int getVisibleState() {
        return visibleState;
    }

    public void setCheckMine(boolean checkMine) {
        this.checkMine = checkMine;
    }

    public boolean getCheckMine() {
        return checkMine;
    }

    public void makeConnection(ArrayList<Block> blocks) {
        if (!Util.isLeft(index) && !Util.isTop(index)) {
            connections.add(blocks.get(index - 1 - BLOCK_COUNT_X));
        }
        if (!Util.isTop(index)) {
            connections.add(blocks.get(index - BLOCK_COUNT_X));
        }
        if (!Util.isRight(index) && !Util.isTop(index)) {
            connections.add(blocks.get(index + 1 - BLOCK_COUNT_X));
        }

        if (!Util.isLeft(index)) {
            connections.add(blocks.get(index - 1));
        }

        if (!Util.isRight(index)) {
            connections.add(blocks.get(index + 1));
        }

        if (!Util.isLeft(index) && !Util.isBottom(index)) {
            connections.add(blocks.get(index - 1 + BLOCK_COUNT_X));
        }

        if (!Util.isBottom(index)) {
            connections.add(blocks.get(index + BLOCK_COUNT_X));
        }

        if (!Util.isBottom(index) && !Util.isRight(index)) {
            connections.add(blocks.get(index + 1 + BLOCK_COUNT_X));
        }

        for (Block block : connections) {
            if (block.getBlockState() == BLOCK_STATE_MINE)
                this.neighborMineCount++;
        }
    }

    public boolean checkConnectionsHasMine() {
        int arrNum = 0;
        for (Block block : connections) {
            if (block.blockState == BLOCK_STATE_MINE &&
                    block.checkMine) {
                num[arrNum] = block.index;
                arrNum++;
            }
        }

        for (Block block : connections) {
            if (checkMineEqualsClickMine(block.index))
                block.visibleState = BLOCK_VISIBLE;
            if (block.neighborMineCount == 0) {
                block.click(false);
            }
            if (block.visibleState == BLOCK_VISIBLE && block.blockState == BLOCK_STATE_MINE)
                return true;
        }
        return false;
    }

    private boolean checkMineEqualsClickMine(int index) {
        for (Integer n : num) {
            if (index == n)
                return false;
        }
        return true;
    }

    public void click(boolean visible) {
        if (visible) {
            if (this.visibleState == BLOCK_VISIBLE) return;
        }
        if (!this.checkMine)
            this.visibleState = BLOCK_VISIBLE;

        if (this.neighborMineCount == 0 && this.blockState != BLOCK_STATE_MINE) {
            for (Block block : connections) {
                block.click(true);
            }
        }


    }


    public void setIndex(int index) {
        this.index = index;
        this.x = Util.getPosXByIndex(index);
        this.y = Util.getPosYByIndex(index);
    }

    public void setBlockState(int state) {
        this.blockState = state;
    }


    public void mineClick() {
        this.visibleState = BLOCK_VISIBLE;
    }

    public void render() {

        this.pApplet.stroke(100);
        this.pApplet.strokeWeight(2);

        if (this.visibleState == BLOCK_INVISIBLE) {
            this.pApplet.fill(200);
            this.pApplet.rect(this.x, this.y,
                    BLOCK_SIZE_X,
                    BLOCK_SIZE_Y);

        } else {
            this.pApplet.fill(100);
            this.pApplet.stroke(50);
            this.pApplet.rect(this.x, this.y,
                    BLOCK_SIZE_X,
                    BLOCK_SIZE_Y);

            if (this.blockState == BLOCK_STATE_NUMBER) {
                this.pApplet.fill(0);
                this.pApplet.textSize(BLOCK_SIZE_X / 2);
                this.pApplet.text("" + this.neighborMineCount,
                        this.x + (BLOCK_SIZE_X / 2),
                        this.y + (BLOCK_SIZE_Y / 2));
            }
        }

        if (this.checkMine) {
            pApplet.fill(255, 0, 0);
        }

    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
