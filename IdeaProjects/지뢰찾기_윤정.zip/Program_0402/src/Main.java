import processing.core.PApplet;
import processing.core.PImage;
import processing.event.KeyEvent;

public class Main extends PApplet {

    public static void main(String[] args) {
        Main.main("Main");
    }

    private Map mineMap = new Map(this);
    private PImage mineImg;
    private PImage mineFlagImg;
    private int count = 0;
    private int hour = 0;
    private int minute = 0;
    private int second = 0;
    private int minuteCount = 0;
    private int secondCount = 0;
    private boolean gamePlaying = true;


    public void settings() {
        size(900, 900);

    }

    public void setup() {
        background(0);
        if (count == 0) {
            mineImg = loadImage("./data/571960-200.png");
            mineFlagImg = loadImage("./data/15222-200.png");

        }
        count++;
    }

    private int tick = 0;

    public void draw() {

        if (gamePlaying)
            tick++;

        background(0);
        mineMap.render(mineImg, mineFlagImg);
        mineMap.mineDraw();

        if (mineMap.getClickMineState()) {
            fill(255, 0, 0);
            textSize(40);
            text("Game Over, You Lose", 240, 150);
            textSize(10);
            gamePlaying = false;
        }

        if (mineMap.VisibleBlock() && mineMap.checkMineEqualsRealMine()) {
            fill(255, 0, 0);
            textSize(40);
            text("You Win", 350, 150);
            textSize(10);
            gamePlaying = false;
        }

        fill(0, 255, 0);
        textSize(30);
        text("The number of Mine" + ":" + mineMap.getMineCount(), 50, 50);

        if (tick % 60 == 0 && tick != 0) {
            second++;
            secondCount = 0;
        }
        if (second % 60 == 0 && second != 0) {
            if (secondCount == 0) {
                minute++;
                secondCount = 1;
                minuteCount = 0;
            }
            second = 0;
        }
        if (minute % 60 == 0 && minute != 0) {
            if (minuteCount == 0) {
                hour++;
                minuteCount = 1;
            }
        }

        fill(100, 0, 110);
        textSize(30);
        text(hour + ":" + minute + ":" + second, 50, 100);

    }

    public void keyPressed(KeyEvent event) {
        if (gamePlaying)
            mineMap.click(event.getKey());
    }

}
